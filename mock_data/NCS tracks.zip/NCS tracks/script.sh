#!/usr/bin/bash

# move into the NCS tracks folder

# converts all MP3s to 32 kbps .opus files
for file in *.mp3; do
  ffmpeg -i "${file}" -c:a libopus -b:a 32k -vbr on -compression_level 10 -frame_duration 60 -application voip "${file%mp3}opus"
  rm "${file}"
done

# extracts metadata from each file and writes it to a CSVs
exiftool . -ext opus -r -Title -Artist -Album -Genre -Year -Originalyear -Track -SourceFile -csvDelim '\t' -csv > ../tracks_data.csv
